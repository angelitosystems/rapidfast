# RapidFAST Framework - Versión Beta

![RapidFAST Logo](https://via.placeholder.com/700x150?text=RapidFAST+Framework+BETA)

## ⚡ Framework para desarrollo rápido de APIs con TypeScript y Express

Esta es una versión **BETA** de RapidFAST. Contiene características experimentales que pueden cambiar antes de la versión estable.

[![NPM Version](https://img.shields.io/npm/v/@angelitosystems/rapidfast/beta.svg)](https://www.npmjs.com/package/@angelitosystems/rapidfast)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

## 🚨 Advertencia

Esta versión beta es para pruebas y puede contener errores. No se recomienda para uso en producción.

## 🆕 Nuevas características en esta beta

- Corrección de errores en los decoradores de parámetros
- Mejora en la compatibilidad de tipos en TypeScript
- Actualización del método `initialize` para registrar módulos
- Corrección de errores en el middleware de extracción de parámetros

## 📋 Instalación de la versión beta

```bash
npm install @angelitosystems/rapidfast@beta
```

## 🔄 Migración desde versiones anteriores

Si estás actualizando desde una versión anterior, ten en cuenta los siguientes cambios:

1. El método `app.register()` ha sido reemplazado por `app.initialize([])` para registrar módulos.

Para actualizar automáticamente tu proyecto, puedes usar el comando:

```bash
npx @angelitosystems/rapidfast fix
```

## 🐛 Reporte de errores

Si encuentras algún error en esta versión beta, por favor repórtalo en nuestro [repositorio de GitHub](https://github.com/angelitosystems/rapidfast/issues).

## 📝 Notas de la versión

### v1.0.5-beta

- Corrección de errores en los decoradores de parámetros
- Mejora en la compatibilidad de tipos en TypeScript
- Actualización del método `initialize` para registrar módulos
- Corrección de errores en el middleware de extracción de parámetros 